"""Model request boundary and honest attribution of upstream outcomes.

Every terminal result is attributed to the upstream component that produced it.
Facai never rewrites an upstream refusal, timeout, rate limit, authentication,
transport, tool or resource failure as its own decision, and a model response is
never treated as mission success.
"""

import httpx
import os
import re
import threading
import time


class _KeyRotation:
    """Short-lived per-endpoint/env-reference cooldowns; never stores secrets.

    MODEL-001 跨进程共享冷却：可选挂一个 Store 后端（SQLite）。内存字典仍是
    快路径（本进程的 monotonic 时钟）；落盘行走墙钟 epoch，其他进程读同一行
    即可看到同一份冷却。计量计数仍只在进程内存（口径不变，重启清零）。"""

    def __init__(self, store=None):
        self._lock = threading.Lock()
        self._cooldown = {}
        self._next = {}
        self._store = store
        # MODEL-001 每Key计量：按 (endpoint, 环境变量名) 记调用数/结局/tokens。
        # 只存环境变量名与上游自报计数，绝存不进密钥值；进程内存，重启即清零
        # （与冷却不同生命周期：冷却是跨进程共享的，计量是进程内的）。
        self._usage = {}

    def _shared(self, endpoint, refs):
        """Split refs by the shared SQLite backend, if attached: (ready, statuses)."""
        if self._store is None:
            return list(refs), {}
        rows = self._store.key_cooldown_map(endpoint, refs)
        ready = [ref for ref in refs if rows.get(ref) is None]
        return ready, {ref: row[1] for ref, row in rows.items() if row}

    def candidates(self, endpoint, refs):
        with self._lock:
            now = time.monotonic()
            ready = [ref for ref in refs if self._cooldown.get((endpoint, ref), (0, None))[0] <= now]
            if not ready:
                return []
            start = self._next.get(endpoint, 0) % len(ready)
            self._next[endpoint] = start + 1
            ordered = ready[start:] + ready[:start]
        # Backend merge outside the lock: one indexed SQLite read per request.
        shared_ready, _ = self._shared(endpoint, ordered)
        return shared_ready

    def penalize(self, endpoint, ref, status):
        ttl = 60 if status in (401, 403) else 10
        with self._lock:
            # 429 is temporary quota pressure; an auth failure needs a longer
            # pause before the same bad key is retried on another request.
            self._cooldown[(endpoint, ref)] = (time.monotonic() + ttl, status)
        if self._store is not None:
            # Wall-clock epoch for other processes; memory keeps monotonic.
            self._store.key_cooldown_set(endpoint, ref, time.time() + ttl, status)

    def record(self, endpoint, ref, status, usage=None):
        """Meter one real upstream attempt made with this env reference.

        Counters split by classified outcome (被拒率与失败原因细分的基础)；
        token sums only ever accumulate what the provider itself reported in
        the response body — nothing is estimated here."""
        with self._lock:
            entry = self._usage.setdefault((endpoint, ref), {
                "calls": 0, "completed": 0, "rate_limited": 0,
                "auth_failed": 0, "failed_other": 0,
                "input_tokens": 0, "output_tokens": 0})
            entry["calls"] += 1
            if status == "MODEL_COMPLETED":
                entry["completed"] += 1
            elif status == "MODEL_RATE_LIMITED":
                entry["rate_limited"] += 1
            elif status == "MODEL_AUTH_FAILED":
                entry["auth_failed"] += 1
            else:
                entry["failed_other"] += 1
            if isinstance(usage, dict):
                try:
                    entry["input_tokens"] += int(usage.get("prompt_tokens")
                                                 or usage.get("input_tokens") or 0)
                    entry["output_tokens"] += int(usage.get("completion_tokens")
                                                  or usage.get("output_tokens") or 0)
                except (TypeError, ValueError):
                    pass

    def usage_snapshot(self, endpoint, refs):
        """Counters for the configured refs of one endpoint (unused key = zeroed row)."""
        with self._lock:
            return {ref: dict(self._usage.get((endpoint, ref), {
                "calls": 0, "completed": 0, "rate_limited": 0,
                "auth_failed": 0, "failed_other": 0,
                "input_tokens": 0, "output_tokens": 0})) for ref in refs}

    def unavailable_status(self, endpoint, refs):
        with self._lock:
            failures = [self._cooldown.get((endpoint, ref), (0, None))[1] for ref in refs]
        if self._store is not None:
            _, shared = self._shared(endpoint, refs)
            failures = [shared.get(ref) if shared.get(ref) is not None else mem
                        for ref, mem in zip(refs, failures)]
        return ("MODEL_AUTH_FAILED" if failures and all(s in (401, 403) for s in failures)
                else "MODEL_RATE_LIMITED")


_KEY_ROTATION = _KeyRotation()
# Public alias: apps construct their own rotation with a shared cooldown backend.
KeyRotation = _KeyRotation



def key_usage(endpoint, refs, rotation=None):
    """Per-env-reference metering view for admin surfaces (MODEL-001).

    Keys of the returned dict are environment-variable NAMES; secret values
    are never recorded anywhere in this module."""
    return (rotation or _KEY_ROTATION).usage_snapshot(str(endpoint).rstrip("/"), refs)

# The full set of upstream outcomes the gateway can report. Keeping the labels
# explicit lets the console present the precise cause instead of a generic error.
OUTCOMES = (
    "MODEL_COMPLETED",
    "MODEL_REFUSED",
    "MODEL_TIMEOUT",
    "MODEL_RATE_LIMITED",
    "MODEL_AUTH_FAILED",
    "MODEL_TRANSPORT_FAILED",
    "MODEL_TOOL_FAILED",
    "MODEL_RESOURCE_UNAVAILABLE",
    "MODEL_FAILED",
)

# Chinese labels are shown next to the raw status so the owner reads the cause.
OUTCOME_LABELS = {
    "MODEL_COMPLETED": "上游模型已完成",
    "MODEL_REFUSED": "上游模型拒绝回答",
    "MODEL_TIMEOUT": "上游请求超时",
    "MODEL_RATE_LIMITED": "上游限流",
    "MODEL_AUTH_FAILED": "上游认证失败",
    "MODEL_TRANSPORT_FAILED": "网络传输失败",
    "MODEL_TOOL_FAILED": "上游工具调用失败",
    "MODEL_RESOURCE_UNAVAILABLE": "上游资源不可用",
    "MODEL_FAILED": "上游返回错误",
}


def error_text(body):
    """Flatten an upstream error object into lowercase searchable text."""
    if not isinstance(body, dict):
        return ""
    error = body.get("error")
    if isinstance(error, dict):
        return " ".join(str(error[key]) for key in ("type", "code", "message")
                         if error.get(key)).lower()
    if error:
        return str(error).lower()
    return ""


def coerce_json_object(body):
    """Normalize any non-object JSON body into an object.

    Some upstreams return a bare JSON array on failure -- for example Gemini's
    OpenAI-compatible endpoint answers ``[{"error": {...}}]`` instead of an
    object. Treating the parsed body as a dict unconditionally would crash
    classification with ``AttributeError`` and turn an upstream 404 into a
    Facai 500, so the first object element is used and everything else becomes
    an empty object.
    """
    if isinstance(body, dict):
        return body
    if isinstance(body, list):
        for item in body:
            if isinstance(item, dict):
                return item
        return {}
    return {}


def classify_response(status, body):
    """Map an HTTP response to exactly one upstream outcome."""
    if status in (401, 403):
        return "MODEL_AUTH_FAILED"
    if status == 429:
        return "MODEL_RATE_LIMITED"
    if status == 504:
        return "MODEL_TIMEOUT"
    if status in (502, 503, 507):
        return "MODEL_RESOURCE_UNAVAILABLE"
    body = body or {}
    text = error_text(body)
    if "tool" in text:
        return "MODEL_TOOL_FAILED"
    if status >= 400:
        return "MODEL_FAILED"
    choices = body.get("choices") or []
    first = choices[0] if choices else {}
    message = first.get("message") or {}
    finish_reason = first.get("finish_reason")
    if message.get("refusal") or finish_reason in {"content_filter", "refusal"}:
        return "MODEL_REFUSED"
    if finish_reason == "tool_error" or first.get("tool_error") or message.get("tool_error"):
        return "MODEL_TOOL_FAILED"
    if body.get("type") == "error":
        return "MODEL_FAILED"
    if body.get("stop_reason") == "refusal" or any(
            isinstance(block, dict) and block.get("type") == "refusal"
            for block in body.get("content", [])):
        return "MODEL_REFUSED"
    if body.get("stop_reason") == "tool_error":
        return "MODEL_TOOL_FAILED"
    return "MODEL_COMPLETED"


def _is_anthropic(model):
    identity = " ".join(str(model.get(key, "")) for key in
                         ("provider", "provider_id", "id")).lower()
    return "anthropic" in identity or "claude" in identity


def _anthropic_request(endpoint, messages, model_name, max_tokens=8192):
    """Build the Messages API URL and body from Facai's role/content messages."""
    if endpoint.endswith("/v1/messages"):
        url = endpoint
    elif endpoint.endswith("/v1"):
        url = f"{endpoint}/messages"
    else:
        url = f"{endpoint}/v1/messages"
    system = []
    conversation = []
    for message in messages:
        role, content = message.get("role"), message.get("content", "")
        if role == "system":
            if isinstance(content, str):
                system.append(content)
            elif isinstance(content, list):
                system.extend(block.get("text", "") for block in content
                              if isinstance(block, dict) and block.get("type") == "text")
        else:
            conversation.append({"role": role, "content": content})
    try:
        max_tokens = int(max_tokens)
    except (TypeError, ValueError):
        max_tokens = 8192
    payload = {"model": model_name, "messages": conversation,
               "max_tokens": max(1, min(max_tokens, 32768))}
    if system:
        payload["system"] = "\n\n".join(system)
    return url, payload


def _anthropic_content(body):
    blocks = body.get("content") or []
    parts = [block.get("text", "") for block in blocks
             if isinstance(block, dict) and block.get("type") == "text"]
    return "".join(parts) if parts else None


def _anthropic_usage(body):
    usage = body.get("usage")
    if not isinstance(usage, dict):
        return usage
    return {"input_tokens": usage.get("input_tokens"),
            "output_tokens": usage.get("output_tokens")}


def _result(status, http_status, content=None, upstream=None, reason=None, usage=None):
    return {"status": status, "label": OUTCOME_LABELS.get(status),
            "http_status": http_status, "content": content,
            "upstream": upstream, "reason": reason, "usage": usage}


async def complete(model, messages, client=None, timeout=30, rotation=None):
    """Route one completion. ``rotation`` lets an app instance own its key
    pool state (shared cooldown backend included) instead of the process
    global default."""
    rotation = rotation if rotation is not None else _KEY_ROTATION
    endpoint = model.get("endpoint", "").rstrip("/")
    if not endpoint.startswith(("http://", "https://")):
        raise ValueError("Model endpoint must be HTTP(S)")
    anthropic = _is_anthropic(model)
    refs = model.get("api_key_envs")
    if refs is not None and (not isinstance(refs, list) or not refs
                            or len(refs) > 16 or any(not isinstance(ref, str)
                            or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", ref)
                            for ref in refs) or len(set(refs)) != len(refs)):
        raise ValueError("api_key_envs must be 1-16 unique environment variable names")
    # User-owned decrypted keys and the legacy single env reference keep
    # exactly their previous one-attempt behavior.
    rotating = bool(refs) and not model.get("api_key")
    if rotating:
        configured = [ref for ref in refs if os.getenv(ref)]
        names = rotation.candidates(endpoint, configured)
        if not names:
            return _result("MODEL_AUTH_FAILED" if not configured else
                           rotation.unavailable_status(endpoint, configured), None,
                           reason="Configured model keys unavailable or cooling down")
        credentials = [(name, os.getenv(name)) for name in names]
    else:
        credentials = [(None, model.get("api_key") or os.getenv(model.get("api_key_env", "")))]
    if anthropic:
        url, payload = _anthropic_request(endpoint, messages, model["model"],
                                          model.get("max_tokens", 8192))
    else:
        url, payload = f"{endpoint}/chat/completions", {"model": model["model"], "messages": messages}
    own_client = client is None
    if own_client:
        try:
            timeout = float(timeout)
        except (TypeError, ValueError):
            timeout = 30
        client = httpx.AsyncClient(timeout=max(1.0, timeout))
    try:
        for ref, api_key in credentials:
            headers = {"anthropic-version": "2023-06-01"} if anthropic else {}
            if api_key:
                headers["x-api-key" if anthropic else "Authorization"] = (
                    api_key if anthropic else f"Bearer {api_key}")
            try:
                response = await client.post(url, json=payload, headers=headers)
            except httpx.TimeoutException as exc:
                return _result("MODEL_TIMEOUT", None, upstream={"error": type(exc).__name__},
                               reason="上游请求超时")
            except httpx.RequestError as exc:
                return _result("MODEL_TRANSPORT_FAILED", None, upstream={"error": type(exc).__name__},
                               reason="网络传输失败")
            try:
                body = coerce_json_object(response.json())
            except ValueError:
                body = {}
            status = classify_response(response.status_code, body)
            if anthropic:
                content = _anthropic_content(body)
                if body.get("stop_reason") == "refusal":
                    status = "MODEL_REFUSED"
            else:
                content = ((body.get("choices") or [{}])[0].get("message") or {}).get("content")
            failed = status != "MODEL_COMPLETED"
            usage = (_anthropic_usage(body) if anthropic else body.get("usage")) if isinstance(body, dict) else None
            if rotating:
                # 每Key计量先于冷却记账：这一把真实发生的上游调用必须留下计数，
                # 包括压轴 key 的最后一次失败（它不再 continue，直接返回）。
                rotation.record(endpoint, ref, status, usage)
            result = _result(status, response.status_code, content,
                             upstream=body if failed else None,
                             reason=(error_text(body) or status) if failed else None,
                             usage=usage)
            if rotating:
                # 归因随行：调用方与展示层能说出这一步用的是哪个环境引用，
                # 计量才对得上号（值只是变量名，不是密钥本体）。
                result["key_env"] = ref
            if rotating and status in {"MODEL_RATE_LIMITED", "MODEL_AUTH_FAILED"}:
                rotation.penalize(endpoint, ref, response.status_code)
                if (ref, api_key) != credentials[-1]:
                    continue
            return result
    finally:
        if own_client:
            await client.aclose()
