"""Facai Cloud foundation."""
