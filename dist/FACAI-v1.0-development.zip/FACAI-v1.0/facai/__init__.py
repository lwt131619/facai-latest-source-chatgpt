"""Facai Cloud foundation."""
